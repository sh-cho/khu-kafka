/**
 *	Kafka Program
 */
#include "KafkaApp.h"
using namespace std;

int main()
{
	//cout << sizeof(chrono::system_clock::time_point) << endl;
	KafkaApp app;
	app.run();


	return 0;
}